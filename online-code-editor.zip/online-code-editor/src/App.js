import React, { useState } from 'react';
import EditorPane from './components/EditorPane';
import PreviewPane from './components/PreviewPane';

function App() {
  const [html, setHtml] = useState('<h1>Hello, World!</h1>');
  const [css, setCss] = useState('h1 { color: #0077cc; text-align: center; }');
  const [js, setJs] = useState("console.log('Welcome to the online editor!');");
  const [runTrigger, setRunTrigger] = useState(0); // Triggers preview refresh

  const runPreview = () => setRunTrigger(prev => prev + 1);

  return (
    <div className="bg-gray-100 min-h-screen p-4">
      <h1 className="text-4xl font-bold text-center text-purple-700 mb-6">🌐 Online Code Editor</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-4 rounded-xl shadow-lg">
          <EditorPane
            html={html}
            css={css}
            js={js}
            setHtml={setHtml}
            setCss={setCss}
            setJs={setJs}
            onRun={runPreview}
          />
        </div>
        <div className="bg-white p-4 rounded-xl shadow-lg">
          <PreviewPane html={html} css={css} js={js} trigger={runTrigger} />
        </div>
      </div>
    </div>
  );
}

export default App;
