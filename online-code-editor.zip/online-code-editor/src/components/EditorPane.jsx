import React from 'react';
import Editor from '@monaco-editor/react';

export default function EditorPane({ html, css, js, setHtml, setCss, setJs, onRun }) {
  return (
    <div className="space-y-6">
      {/* HTML */}
      <div>
        <div className="flex justify-between items-center mb-1">
          <h2 className="text-xl font-semibold text-red-600">HTML Editor</h2>
          <button onClick={onRun} className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700">Run</button>
        </div>
        <Editor height="150px" language="html" value={html} onChange={(v) => setHtml(v || '')} theme="vs-dark" />
      </div>

      {/* CSS */}
      <div>
        <div className="flex justify-between items-center mb-1">
          <h2 className="text-xl font-semibold text-green-600">CSS Editor</h2>
          <button onClick={onRun} className="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700">Run</button>
        </div>
        <Editor height="150px" language="css" value={css} onChange={(v) => setCss(v || '')} theme="vs-dark" />
      </div>

      {/* JavaScript */}
      <div>
        <div className="flex justify-between items-center mb-1">
          <h2 className="text-xl font-semibold text-yellow-500">JavaScript Editor</h2>
          <button onClick={onRun} className="bg-yellow-500 text-white px-3 py-1 rounded hover:bg-yellow-600">Run</button>
        </div>
        <Editor height="150px" language="javascript" value={js} onChange={(v) => setJs(v || '')} theme="vs-dark" />
      </div>
    </div>
  );
}
