import React, { useEffect, useRef } from 'react';

export default function PreviewPane({ html, css, js, trigger }) {
  const iframeRef = useRef();

  useEffect(() => {
    const doc = iframeRef.current?.contentDocument;
    if (!doc) return;

    doc.open();
    doc.write(`
      <html>
        <head>
          <style>${css}</style>
        </head>
        <body>
          ${html}
          <script>${js}<\/script>
        </body>
      </html>
    `);
    doc.close();
  }, [html, css, js, trigger]);

  return (
    <div>
      <h2 className="text-xl font-semibold text-indigo-700 mb-2">Live Preview</h2>
      <iframe
        ref={iframeRef}
        title="Live Preview"
        sandbox="allow-scripts"
        className="w-full h-[400px] border rounded-lg"
      />
    </div>
  );
}
